Hopper mod

Based on jordan4ibanez original mod and optimized by TenPlus1

Hoppers allow for items dropped on top to be sucked in and transfered to chests/hoppers below and beside the original hopper.  Chests above hopper will have items inside transfered into hopper.  Furnaces above hopper will have output transfered into hopper, furnaces below will have hopper items dropped into source material to be cooked and furnaces to the side will have hopper items copied into fuel slot.

Change log:

- 0.1 - Initial release from jordan4ibanez
- 0.2 - Fixed tool glitch (wear was restored by accident)
- 0.3 - transfer function added
- 0.4 - Supports locked chest and protected chest
- 0.5 - Works with 0.4.13's new shift+click for newly placed Hoppers
- 0.6 - Remove formspec from hopper nodes to improve speed for servers
- 0.7 - Halved hopper capacity, can be dug by wooden pick
- 0.8 - Added Napiophelios' new textures and tweaked code
- 0.9 - Added support for Wine mod's wine barrels
- 1.0 - New furances do not work properly with hoppers so old reverted to abm furnaces
- 1.1 - Hoppers now work with new node timer Furnaces.  Reduced Abm's and tidied code
- 1.2 - Added simple API so that hoppers can work with other containers
- 1.3 - Tweaked code to use a single abm and added intllib support
- 1.4 - Simplified hopper placement function and added some nil checks
- 1.5 - Updating to newer functions, requires Minetest 0.4.16 and above.
- 1.6 - Added Void Hopper (use to set container output before placing)

Lucky Blocks: 2
