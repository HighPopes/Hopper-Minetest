
-- define global
hopper = {}
local MP = minetest.get_modpath(minetest.get_current_modname())

-- Intllib
local S

if minetest.get_translator then
 S = minetest.get_translator("hopper")
elseif minetest.get_modpath("intllib") then
 S = intllib.Getter()
else
 S = function(s, a, ...) a = {a, ...}
  return s:gsub("@(%d+)", function(n)
   return a[tonumber(n)]
  end)
 end

end

-- creative check
local creative_mode_cache = minetest.settings:get_bool("creative_mode")
function check_creative(name)
 return creative_mode_cache or minetest.check_player_privs(name, {creative = true})
end

local mapped_containers = {}
-- global function to add new containers
function hopper:add_container(list)

 for n = 1, #list do
  local entry = list[n]
  
  local where = entry[1]
  local node_name = entry[2]
  local dst = entry[3]
  
  if not mapped_containers[node_name] then
   mapped_containers[node_name] = {}
  end
  
  local target_list = mapped_containers[node_name]
  -- check if already added
  local already_added = false
  for i = 1,#target_list do
   if where == target_list[i][1] and dst == target_list[i][2] then
    already_added = true
   end
  end
  if not already_added then
   local t = {where, dst}
   table.insert(target_list, t)
  end
 end
end

-- default containers
hopper:add_container({
 {"bottom", "hopper:hopper", "main"},
 {"side", "hopper:hopper", "main"},
 {"bottom", "hopper:hopper_side", "main"},
 {"side", "hopper:hopper_side", "main"},
 
 {"bottom", "hopper:wood_hopper", "main"},
 {"side", "hopper:wood_hopper", "main"},
 {"bottom", "hopper:wood_hopper_side", "main"},
 {"side", "hopper:wood_hopper_side", "main"},

 {"top", "default:chest", "main"},
 {"bottom", "default:chest", "main"},
 {"side", "default:chest", "main"},

 {"top", "default:furnace", "dst"},
 {"bottom", "default:furnace", "src"},
 {"side", "default:furnace", "fuel"},

 {"top", "default:furnace_active", "dst"},
 {"bottom", "default:furnace_active", "src"},
 {"side", "default:furnace_active", "fuel"},

 {"bottom", "default:chest_locked", "main"},
 {"side", "default:chest_locked", "main"},

 {"top", "default:chest_open", "main"}, --  new animated chests
 {"bottom", "default:chest_open", "main"},
 {"side", "default:chest_open", "main"},

 {"bottom", "default:chest_locked_open", "main"},
 {"side", "default:chest_locked_open", "main"},

 {"top", "minecart:hopper", "main"},
 {"bottom", "minecart:hopper", "main"},
 {"side", "minecart:hopper", "main"},
 
 {"top", "hopper:hopper_side", "main"},
 {"bottom", "hopper:hopper_side", "main"},
 
 {"void", "hopper:hopper", "main"},
 {"void", "hopper:hopper_side", "main"},
 {"void", "hopper:hopper_void", "main"},
 {"void", "default:chest", "main"},
 {"void", "default:chest_open", "main"},
 {"void", "default:furnace", "src"},
 {"void", "default:furnace_active", "src"},
})

-- some elepower mod support
if minetest.get_modpath("elepower") then
 hopper:add_container({
  {"top", "elepower_machines:furnace", "dst"},
  {"bottom", "elepower_machines:furnace", "src"},
  {"side", "elepower_machines:furnace", "src"},
 
  {"top", "elepower_machines:furnace_active", "dst"},
  {"bottom", "elepower_machines:furnace_active", "src"},
  {"side", "elepower_machines:furnace_active", "src"},

  {"top", "elepower_machines:alloy_furnace", "dst"},
  {"bottom", "elepower_machines:alloy_furnace", "src"},
  {"side", "elepower_machines:alloy_furnace", "src"},
  
  {"top", "elepower_machines:alloy_furnace_active", "dst"},
  {"bottom", "elepower_machines:alloy_furnace_active", "src"},
  {"side", "elepower_machines:alloy_furnace_active", "src"},
 
  {"top", "elepower_machines:coal_alloy_furnace", "dst"},
  {"bottom", "elepower_machines:coal_alloy_furnace", "src"},
  {"side", "elepower_machines:coal_alloy_furnace", "fuel"},
 
  {"top", "elepower_machines:coal_alloy_furnace_active", "dst"},
  {"bottom", "elepower_machines:coal_alloy_furnace_active", "src"},
  {"side", "elepower_machines:coal_alloy_furnace_active", "fuel"},
 
  {"top", "elepower_machines:grindstone", "dst"},
  {"side", "elepower_machines:grindstone", "src"},
 })
end

-- protector redo mod support
if minetest.get_modpath("protector") then

 hopper:add_container({
  {"top", "protector:chest", "main"},
  {"bottom", "protector:chest", "main"},
  {"side", "protector:chest", "main"},
  {"void", "protector:chest", "main"},
 })
end


-- wine mod support
if minetest.get_modpath("wine") then

 hopper:add_container({
  {"top", "wine:wine_barrel", "dst"},
  {"bottom", "wine:wine_barrel", "src"},
  {"side", "wine:wine_barrel", "src"},
  {"void", "wine:wine_barrel", "src"},
 })
end

--------------------
local get_mese_powering_rules = function (node)
 local rules = {
   {x = 0, y = 0, z = 1},
   {x = 1, y = 0, z = 0},
   {x = 0, y = 0, z = -1},
   {x = -1, y = 0, z = 0}
 }
	--for i = 0, node.param2 do
	--	rules = mesecon.rotate_rules_left(rules)
	--end
	return rules
end

local mesecon_rules = {
 effector = {
  action_on = function(pos, node)
   local meta = minetest.get_meta(pos)
   meta:set_string("hopper_locked", "true")
  end,
  action_off = function(pos, node)
   local meta = minetest.get_meta(pos)
   meta:set_string("hopper_locked", "false")
  end,
  
  rules = get_mese_powering_rules,
 },
}

local hopper_node_box_normal ={
 type = "fixed",
 fixed = {
  --funnel walls
  {-0.5, 0.0, 0.4, 0.5, 0.5, 0.5},
  {0.4, 0.0, -0.5, 0.5, 0.5, 0.5},
  {-0.5, 0.0, -0.5, -0.4, 0.5, 0.5},
  {-0.5, 0.0, -0.5, 0.5, 0.5, -0.4},
  --funnel base
  {-0.5, 0.0, -0.5, 0.5, 0.1, 0.5},
  --spout
  {-0.3, -0.3, -0.3, 0.3, 0.0, 0.3},
  {-0.15, -0.3, -0.15, 0.15, -0.5, 0.15},
 },
}

local hopper_node_box_side = {
 type = "fixed",
 fixed = {
  --funnel walls
  {-0.5, 0.0, 0.4, 0.5, 0.5, 0.5},
  {0.4, 0.0, -0.5, 0.5, 0.5, 0.5},
  {-0.5, 0.0, -0.5, -0.4, 0.5, 0.5},
  {-0.5, 0.0, -0.5, 0.5, 0.5, -0.4},
  --funnel base
  {-0.5, 0.0, -0.5, 0.5, 0.1, 0.5},
  --spout
  {-0.3, -0.3, -0.3, 0.3, 0.0, 0.3},
  {-0.7, -0.3, -0.15, 0.15, 0.0, 0.15},
 },
}

local hopper_node_box_void = {
 type = "fixed",
 fixed = {
  --funnel walls
  {-0.5, 0.0, 0.4, 0.5, 0.5, 0.5},
  {0.4, 0.0, -0.5, 0.5, 0.5, 0.5},
  {-0.5, 0.0, -0.5, -0.4, 0.5, 0.5},
  {-0.5, 0.0, -0.5, 0.5, 0.5, -0.4},
  --funnel base
  {-0.5, 0.0, -0.5, 0.5, 0.1, 0.5},
 },
}

-- formspec
local function get_hopper_formspec(pos)

 local spos = pos.x .. "," .. pos.y .. "," ..pos.z
 local formspec =
  "size[8,9]"
  .. default.gui_bg
  .. default.gui_bg_img
  .. default.gui_slots
  .. "list[nodemeta:" .. spos .. ";main;0,0.3;8,4;]"
  .. "list[current_player;main;0,4.85;8,1;]"
  .. "list[current_player;main;0,6.08;8,3;8]"
  .. "listring[nodemeta:" .. spos .. ";main]"
  .. "listring[current_player;main]"

 return formspec
end


-- check where pointing and set normal or side-hopper
local get_hopper_place = function (normal, side, inv_size, speed) 
  
 return function(itemstack, placer, pointed_thing)

 local pos = pointed_thing.above
 local x = pointed_thing.under.x - pos.x
 local z = pointed_thing.under.z - pos.z
 local name = placer:get_player_name() or ""

 if minetest.is_protected(pos, name) then
  minetest.record_protection_violation(pos, name)
  return itemstack
 end

 if x == -1 then
  minetest.set_node(pos, {name = side, param2 = 0})
 elseif x == 1 then
  minetest.set_node(pos, {name = side, param2 = 2})
 elseif z == -1 then
  minetest.set_node(pos, {name = side, param2 = 3})
 elseif z == 1 then
  minetest.set_node(pos, {name = side, param2 = 1})

 else
  minetest.set_node(pos, {name = normal})
 end

 if not check_creative(placer:get_player_name()) then
  itemstack:take_item()
 end

 -- set metadata
 local meta = minetest.get_meta(pos)
 meta:set_string("hopper_locked", "false")
 local inv = meta:get_inventory()

 inv:set_size("main", inv_size)

 meta:set_string("owner", name)
 meta:set_int("speed", speed)
 meta:set_int("count", 0)
 return itemstack
 end

end

-- hopper
local def_can_dig = function(pos, player)
 local inv = minetest.get_meta(pos):get_inventory()
 return inv:is_empty("main")
end

local def_on_rightclick = function(pos, node, clicker, itemstack)
 if not minetest.get_meta(pos)
 or minetest.is_protected(pos, clicker:get_player_name()) then
  return itemstack
 end

 minetest.show_formspec(clicker:get_player_name(),
  node.name, get_hopper_formspec(pos))
end

minetest.register_node("hopper:hopper", {
 description = S("Hopper (Place onto sides for side-hopper)"),
 groups = {cracky = 3},
 drawtype = "nodebox",
 paramtype = "light",
 tiles = {"hopper_top.png", "hopper_top.png", "hopper_front.png"},
 inventory_image = "hopper_inv.png",
 node_box = hopper_node_box_normal,

 on_place = get_hopper_place("hopper:hopper", "hopper:hopper_side", 4*4, 1),
  
 can_dig = def_can_dig,
 on_rightclick = def_on_rightclick,
 
 on_rotate = screwdriver.disallow,
 on_blast = function() end,
 
 mesecons = mesecon_rules,
})

-- side hopper
minetest.register_node("hopper:hopper_side", {
 description = S("Side Hopper (Place into crafting to return normal Hopper)"),
 groups = {cracky = 3, not_in_creative_inventory = 1},
 drawtype = "nodebox",
 paramtype = "light",
 paramtype2 = "facedir",
 tiles = {
  "hopper_top.png", "hopper_top.png", "hopper_back.png",
  "hopper_side.png", "hopper_back.png", "hopper_back.png"
 },
 inventory_image = "hopper_side_inv.png",
 drop = "hopper:hopper",
 node_box = hopper_node_box_side,

 on_place = get_hopper_place("hopper:hopper", "hopper:hopper_side", 4*4, 1),
 
 can_dig = def_can_dig,
 on_rightclick = def_on_rightclick,
 
 on_rotate = screwdriver.rotate_simple,
 on_blast = function() end,
 
 mesecons = mesecon_rules,
})

--- Wood Hopper

minetest.register_node("hopper:wood_hopper", {
 description = S("Wooden Hopper (Place onto sides for side-hopper)"),
 groups = {cracky = 3},
 drawtype = "nodebox",
 paramtype = "light",
 tiles = {"wood_hopper.png^wood_hopper_top.png", "wood_hopper.png^wood_hopper_top.png", "wood_hopper.png^wood_hopper_front.png"},
 inventory_image = "wood_hopper_inv.png",
 node_box = hopper_node_box_normal,

 on_place = get_hopper_place("hopper:wood_hopper", "hopper:wood_hopper_side", 4*2, 3),
  
 can_dig = def_can_dig,
 on_rightclick = def_on_rightclick,
 
 on_rotate = screwdriver.disallow,
 on_blast = function() end,
 
 mesecons = mesecon_rules,
})

-- side hopper
minetest.register_node("hopper:wood_hopper_side", {
 description = S("Wooden Side Hopper (Place into crafting to return normal Hopper)"),
 groups = {cracky = 3, not_in_creative_inventory = 1},
 drawtype = "nodebox",
 paramtype = "light",
 paramtype2 = "facedir",
 tiles = {
  "wood_hopper.png^wood_hopper_top.png", "wood_hopper.png^wood_hopper_top.png", "wood_hopper.png^wood_hopper_back.png",
  "wood_hopper.png^wood_hopper_side.png", "wood_hopper.png^wood_hopper_back.png", "wood_hopper.png^wood_hopper_back.png"
 },
 inventory_image = "hopper_side_inv.png",
 drop = "hopper:wood_hopper",
 node_box = hopper_node_box_side,

 on_place = get_hopper_place("hopper:wood_hopper", "hopper:wood_hopper_side", 4*2, 3),
  
 can_dig = def_can_dig,
 on_rightclick = def_on_rightclick,
 
 on_rotate = screwdriver.rotate_simple,
 on_blast = function() end,
 
 mesecons = mesecon_rules,
})


---
local player_void = {}

-- void hopper
minetest.register_node("hopper:hopper_void", {
 description = S("Void Hopper (Use first to set destination container)"),
 groups = {cracky = 3},
 drawtype = "nodebox",
 paramtype = "light",
 tiles = {"hopper_top.png", "hopper_top.png", "hopper_front.png"},
 inventory_image = "default_obsidian.png^hopper_inv.png",
 node_box = hopper_node_box_void,

 on_use = function(itemstack, player, pointed_thing)

  if pointed_thing.type ~= "node" then
   return
  end

  local pos = pointed_thing.under
  local name = player:get_player_name()
  local node = minetest.get_node(pos).name
  local ok

  if minetest.is_protected(pos, name) then
   minetest.record_protection_violation(pos, name)
   return itemstack
  end

  for name,_ in pairs(mapped_containers) do
   if node == name then
    ok = true
   end
  end

  if ok then
   minetest.chat_send_player(name, S("Output container set"
    .. " " .. minetest.pos_to_string(pos)))
   player_void[name] = pos
  else
   minetest.chat_send_player(name, S("Not a registered container!"))
   player_void[name] = nil
  end
 end,

 on_place = function(itemstack, placer, pointed_thing)

  local pos = pointed_thing.above
  local name = placer:get_player_name() or ""

  if not player_void[name] then
   minetest.chat_send_player(name, S("No container position set!"))
   return itemstack
  end

  if minetest.is_protected(pos, name) then
   minetest.record_protection_violation(pos, name)
   return itemstack
  end

  if not check_creative(placer:get_player_name()) then
   itemstack:take_item()
  end

  minetest.set_node(pos, {name = "hopper:hopper_void", param2 = 0})

  local meta = minetest.get_meta(pos)
  local inv = meta:get_inventory()

  inv:set_size("main", 4*4)

  meta:set_string("owner", name)
  meta:set_string("void", minetest.pos_to_string(player_void[name]))
  meta:set_int("speed", 1)
  meta:set_int("count", 0)
  return itemstack
 end,
  
 can_dig = function(pos, player)

  local inv = minetest.get_meta(pos):get_inventory()

  return inv:is_empty("main")
 end,

 on_rightclick = function(pos, node, clicker, itemstack)

  if not minetest.get_meta(pos)
  or minetest.is_protected(pos, clicker:get_player_name()) then
   return itemstack
  end

  minetest.show_formspec(clicker:get_player_name(),
   "hopper:hopper", get_hopper_formspec(pos))
 end,

 on_rotate = screwdriver.disallow,
 on_blast = function() end,
})

-- check if list1 can take items from list2
local can_take_items = function(inv1, inv2) 
  if #inv1 == 0 then
   -- we are empty
   return true
  end
  if #inv2 == 0 then
   -- nothing to take
   return false
  end
  for i = 1, #inv1 do
   local stack1 = inv1[i]
   if stack1:get_free_space() > 0 then
    local target = stack1:get_name()
    for j = 1, #inv2 do
     local stack2 = inv2[j]
     if stack2:get_name() == target and stack2:get_free_space() > 0 then
      return true
     end
    end
   end
  end
  return false
end

-- transfer function
local transfer = function(src, srcpos, dst, dstpos)
 -- source inventory
 local inv = minetest.get_meta(srcpos):get_inventory()
 -- destination inventory
 local inv2 = minetest.get_meta(dstpos):get_inventory()
 -- check for empty source or no inventory
 if not inv or not inv2 or inv:is_empty(src) == true then
  return
 end
 
 local stack, item
 -- transfer item
 for i = 1, inv:get_size(src) do
  stack = inv:get_stack(src, i)
  item = stack:get_name()
  -- if slot not empty and room for item in destination
  if item ~= ""
  and inv2:room_for_item(dst, item) then
   -- is item a tool
   if stack:get_wear() > 0 then
    inv2:add_item(dst, stack:take_item(stack:get_count()))
    inv:set_stack(src, i, nil)
   else -- not a tool
    stack:take_item(1)
    inv2:add_item(dst, item)
    inv:set_stack(src, i, stack)
   end
   return
  end
 end
 return
end

local has_rail_on_top = function (pos) 
 local node = minetest.get_node({x = pos.x,y = pos.y+1,z = pos.z}).name
 if node == "ignore" then
  local vm = minetest.get_voxel_manip()
  local emin, emax = vm:read_from_map(pos, pos)
  local area = VoxelArea:new{
   MinEdge = emin,
   MaxEdge = emax,
  }
  local data = vm:get_data()
  local vi = area:indexp(pos)
  node = minetest.get_name_from_content_id(data[vi])
 end
 if minetest.get_item_group(node, "rail") == 0 then
  return false
 end
 return true
end

local hopper_names = {
  normal = {
    "hopper:hopper", "hopper:wood_hopper"
  },
  side = {
    "hopper:hopper_side", "hopper:wood_hopper_side"
  },
  void = {
    "hopper:hopper_void"
  },
}

local is_hopper_type = function(name, type)
 local t = hopper_names[type]
 if not t then
  return false
 end
 for i,hname in ipairs(t) do
  if hname == name then
   return true
  end
 end
 return false
end

local is_hopper = function(name)
 for key,value in pairs(hopper_names) do
  if is_hopper_type(name, key) then
   return true
  end
 end
 return false
end

local is_hopper_below = function(pos)
 local below_pos = {
   x = pos.x,
   y = pos.y - 1,
   z = pos.z
 }
 local below = minetest.get_node(below_pos)
 if below and is_hopper(below.name) then
  -- if we are locked ignore us
  if minetest.get_meta(below_pos):get_string("hopper_locked") == "true" then
   return false
  end
  -- if we can't take any items ignore us
  if is_hopper_type(minetest.get_node(pos).name, "side") then
   local inv1 = minetest.get_meta(below_pos):get_inventory():get_list("main")
   local inv2 = minetest.get_meta(pos):get_inventory():get_list("main")
     
   if not can_take_items(inv1, inv2) then
    return false
   end
  end
  return true
 end
 return false
end

local get_hopper_front = function(name, pos) 
  local front = nil
  -- if side hopper check which way spout is facing
  if is_hopper_type(name, "side") then
   local face = minetest.get_node(pos).param2
   if face == 0 then
    front = {x = pos.x - 1, y = pos.y, z = pos.z}
   elseif face == 1 then
    front = {x = pos.x, y = pos.y, z = pos.z + 1}
   elseif face == 2 then
    front = {x = pos.x + 1, y = pos.y, z = pos.z}
   elseif face == 3 then
    front = {x = pos.x, y = pos.y, z = pos.z - 1}
   end
  elseif is_hopper_type(name, "void") then
   local meta = minetest.get_meta(pos)
   if meta then
    front = minetest.string_to_pos(meta:get_string("void"))
   end
  elseif is_hopper_type(name, "normal") then
   -- otherwise normal hopper, output downwards
   front = {x = pos.x, y = pos.y - 1, z = pos.z}
  end
  return front
end
-- hopper workings


minetest.register_abm({

 label = "Hopper suction and transfer",
 nodenames = {
   "hopper:hopper", "hopper:hopper_side", "hopper:hopper_void",
   "hopper:wood_hopper", "hopper:wood_hopper_side", 
 },
 interval = 1.0,
 chance = 1,
 catch_up = false,

 action = function(pos, node, active_object_count, active_object_count_wider)
  
  local meta = minetest.get_meta(pos)
  if meta:get_string("hopper_locked") == "true" then
   meta:set_int("count", 0)
   return
  end
  local count = meta:get_int("count")
  local speed = meta:get_int("speed")
  if count + 1 < speed then
   meta:set_int("count", count + 1)
   return
  end
  meta:set_int("count", 0)
   
  local inv = meta:get_inventory()
  
  for _,object in pairs(minetest.get_objects_inside_radius(pos, 1)) do
   local lua_ent = object:get_luaentity()
   if not object:is_player()
    and lua_ent
    and lua_ent.name == "__builtin:item"
    and inv then
     if object:get_pos().y - pos.y >= 0.3 then
    
      local stack = ItemStack(lua_ent.itemstring);
      if has_rail_on_top(pos) == true then
       local singleitemstack = ItemStack(stack:get_name().." 1")
       if inv:room_for_item("main", singleitemstack) then
       
        inv:add_item("main", singleitemstack)
        if stack:get_count() == 1 then
         lua_ent.itemstring = ""
         object:remove()
        else
         lua_ent.itemstring = stack:get_name().." "..(stack:get_count()-1)
        end
        
       end
      else
       local min_size = 10
       if stack:get_count() < min_size then
        min_size = stack:get_count()
       end
       local itemstack = ItemStack(stack:get_name().." "..min_size)
       if inv:room_for_item("main", itemstack) then
        inv:add_item("main", itemstack)
        if stack:get_count() <= min_size then
         lua_ent.itemstring = ""
         object:remove()
        else
         lua_ent.itemstring = stack:get_name().." "..(stack:get_count()-min_size)
        end
       end
      end
     end
  
   end
  end
  
  local front = get_hopper_front(node.name, pos)

  if front then
   -- get node at other end of spout
   local out = minetest.get_node(front).name
   local where, inv, def
   local target = mapped_containers[out]
 
   if target then
    -- do for loop here for api check
    for n = 1, #target do

     where = target[n][1]
     inv = target[n][2]
   
     if where == "bottom"
      and is_hopper_type(node.name, "normal") then
      transfer("main", pos, inv, front)
      minetest.get_node_timer(front):start(1)--0.5)
     -- side hopper into container beside
     elseif where == "side"
     and is_hopper_type(node.name, "side") then
      local can = true
      -- carry items down
      if is_hopper_below(pos) then
       can = false
      end
    
      if can == true then
       transfer("main", pos, inv, front)
      end
      minetest.get_node_timer(front):start(1)
     -- void hopper to destination container
     elseif where == "void"
     and is_hopper_type(node.name, "void") then
      transfer("main", pos, inv, front)
      minetest.get_node_timer(front):start(1)
     end
    end
   end
  end
  
   -- get node above hopper
  local top_pos = {x = pos.x, y = pos.y + 1, z = pos.z}
  local top = minetest.get_node(top_pos).name
  
  -- top node into hopper node below
  target = mapped_containers[top]
  if not target then
   return
  end
  for n = 1, #target do

   where = target[n][1]
   inv = target[n][2]
   
   -- from top node into hopper below
   if where == "top" then
    transfer(inv, top_pos, "main", pos)
    minetest.get_node_timer(top_pos):start(1)
   end
  end
 end,
})


-- hopper recipe
minetest.register_craft({
 output = "hopper:hopper",
 recipe = {
  {"default:steel_ingot", "default:chest", "default:steel_ingot"},
  {"", "default:steel_ingot", ""},
 },
})

-- side hopper to hopper recipe
minetest.register_craft({
 type = "shapeless",
 output = "hopper:hopper",
 recipe = {"hopper:hopper_side"},
})

-- woof hopper recipe
minetest.register_craft({
 output = "hopper:wood_hopper",
 recipe = {
  {"group:wood", "default:chest", "group:wood"},
  {"", "group:wood", ""},
 },
})

-- side hopper to hopper recipe
minetest.register_craft({
 type = "shapeless",
 output = "hopper:wood_hopper",
 recipe = {"hopper:wood_hopper_side"},
})

-- void hopper recipe
if minetest.get_modpath("teleport_potion") then
 minetest.register_craft({
  output = "hopper:hopper_void",
  recipe = {
   {"default:steel_ingot", "default:chest", "default:steel_ingot"},
   {"teleport_potion:potion", "default:steel_ingot", "teleport_potion:potion"},
  },
 })
else
 minetest.register_craft({
  output = "hopper:hopper_void",
  recipe = {
   {"default:steel_ingot", "default:chest", "default:steel_ingot"},
   {"default:diamondblock", "default:steel_ingot", "default:mese"},
  },
 })
end


-- add lucky blocks
if minetest.get_modpath("lucky_block") then

 lucky_block:add_blocks({
  {"dro", {"hopper:hopper"}, 3},
  {"nod", "default:lava_source", 1},
 })
end

if minetest.get_modpath("mesecons") then
 dofile(MP.."/compair.lua")
end

print (S("[MOD] Hopper loaded"))