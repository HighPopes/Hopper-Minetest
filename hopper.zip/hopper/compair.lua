-- Todo add formspec for custom dst and trigger size

local get_output_rules = function(node)
 local rules = {{x = 0, y = 0, z = 1}}
 for i = 0, node.param2 do
  rules = mesecon.rotate_rules_left(rules)
 end
 return rules
end

local get_front = function(pos) 
  local front = nil
  local face = minetest.get_node(pos).param2
  if face == 0 then
   front = {x = pos.x - 1, y = pos.y, z = pos.z}
  elseif face == 1 then
   front = {x = pos.x, y = pos.y, z = pos.z + 1}
  elseif face == 2 then
   front = {x = pos.x + 1, y = pos.y, z = pos.z}
  elseif face == 3 then
   front = {x = pos.x, y = pos.y, z = pos.z - 1}
  end
  return front
end

local mesecon_rules = {
 receptor = {
  state = mesecon.state.off,
  rules = get_output_rules
 },
}

local count_inventory = function (inv, dst) 
  if not inv or not dst then
   return -1
  end
  local count = 0
  for i = 1, inv:get_size(dst) do
   local stack = inv:get_stack(dst, i)
   local item = stack:get_name()
   if minetest.registered_tools[item] then
    count = count + 99
   else
    count = count + stack:get_count()
   end
  end
  return count
end

local get_possible_inventories = function(front)
  local possible_inv_options = {}
  if front then
   local inv = front:get_inventory()
   if inv then
    local list_of_inv = inv:get_lists()
    local i = 1
    for name,t in pairs(list_of_inv) do
     possible_inv_options[i] = name
     i = i + 1
    end
   end
  end
  return possible_inv_options
end

local update_dst = function(pos)
  local meta = minetest.get_meta(pos)
  local last_dst = meta:get_string("dst")
  local new_dst = last_dst
  
  local front = minetest.get_meta(get_front(pos))
  if front then
   local possible = get_possible_inventories(front)
   
   local in_possible = false
   for i=1,#possible do
    if possible[i] == last_dst then
     in_possible = true
    end
   end
   
   if in_possible == false then
    new_dst = possible[1] or ""
   end
  else
   new_dst = ""
  end
  
  meta:set_string("dst", new_dst)
end

local on_timer = function (pos)
 update_dst(pos)

 local node = minetest.get_node(pos)
 local meta = minetest.get_meta(pos)
 
 local front = minetest.get_meta(get_front(pos))
 
 local state = "off"
 if front then
  local inv = front:get_inventory()
  if inv and dst ~= "" then
   local dst = meta:get_string("dst")
   
   local count = count_inventory(inv, dst)
   if count == -1 then
    -- dst was still "" somehow
    state = "off"
   else
    local percent = tonumber(meta:get_string("percent")) or 0
    local total = inv:get_size(dst)*99
    local mode = meta:get_string("mode")
    if mode == "<" then
     if (count/total) < percent/100 then
      state = "on"
     end
    else
     if (count/total) > percent/100 then
      state = "on"
     end
    end
   end
  end
 end
 
 local last_state = meta:get_string("state")
 if last_state ~= state then
  if state == "on" then
   mesecon.receptor_on(pos)
  else
   mesecon.receptor_off(pos)
  end
  meta:set_string("state", state)
 end
  
 local timer = minetest.get_node_timer(pos)
 timer:start(1)
end

local build_formspec = function(pos)
  -- update dst as the node may have changed
  update_dst(pos)
  
  local meta = minetest.get_meta(pos)
  local percent = tonumber(meta:get_string("percent")) or 0
  local dst = meta:get_string("dst")
  
  local front = minetest.get_meta( get_front(pos) )
  
  local trigger = 0
  if front and dst ~= "" then
   local inv = front:get_inventory()
   if inv then
    trigger = (percent/100) * (inv:get_size(dst) * 99)
   end
  end
  
  local dst_list = get_possible_inventories(front)
  -- determine selected index
  local selected_dst = 1
  for i = 1, #dst_list do
   if dst_list[i] == dst then
    selected_dst = i
   end
  end
  
  local dropdown_list = table.concat(dst_list, ",")
  local mode = meta:get_string("mode")
  -- update the formspec
  meta:set_string("formspec",
   "size[7.5,3]"..
   "label[0.5,0.5;Inventory]"..
   "button[6.5,0.4;1,1;mode;<,>]"..
  "dropdown[4,0.5;2,1;dst;"..dropdown_list..";"..selected_dst.."]"..
  "field[0.5,2;5,1;percent;Percent Required;"..percent.."]"..
  "label[5.5,1.85;"..mode.." "..trigger.."]"..
  	"button_exit[2,2.5;3,1;exit;Save]")
end

local boxes = {
  { -6/16, -8/16, -6/16, 6/16, -7/16, 6/16 },  -- the main slab

  { -4/16, -3/16, -4/16, -1/16, -26/64, -3/16 },  -- the plug on top
  { -4/16, -7/16, -2/16, 4/16, -26/64, 2/16 },
  { -4/16, -3/16,  3/16, -1/16, -26/64, 4/16 },

  { -6/16, -7/16, -6/16, -4/16, -27/64, -4/16 },  -- the timer indicator
  { -8/16, -8/16, -1/16, -6/16, -7/16, 1/16 },  -- the two wire stubs
  { 6/16, -8/16, -1/16, 8/16, -7/16, 1/16 }
}

minetest.register_node("hopper:compair", {
 description = "Checks inventory amount",
 tiles       = {"hopper_compair.png"},
 groups = {bendy=2,snappy=1,dig_immediate=2},

 drawtype = "nodebox",
 walkable = true,
 selection_box = {
  type = "fixed",
  fixed = { -8/16, -8/16, -8/16, 8/16, -6/16, 8/16 },
 },
 node_box = {
  type = "fixed",
  fixed = boxes
 },
 paramtype = "light",
 paramtype2 = "facedir",
 sunlight_propagates = true,
 is_ground_content = false,
 
 sounds = default.node_sound_stone_defaults(),
 on_blast = mesecon.on_blastnode,
 drop = "hopper:compair",
 
 after_place_node = function(pos, placer)
  local meta = minetest.get_meta(pos)
  meta:set_string("percent", "95")
  meta:set_string("mode", "<")
  
  local front = minetest.get_meta(get_front(pos))
  if front then
   local possible = get_possible_inventories(front)
   meta:set_string("dst", possible[1] or "")
  else 
   meta:set_string("dst", "")
  end
  build_formspec(pos)
  on_timer(pos)
 end,
 
 on_rightclick =  function(pos, node, clicker, itemstack)
  local meta = minetest.get_meta(pos)
  if not meta or minetest.is_protected(pos, clicker:get_player_name()) then
   return itemstack
  end
  
  build_formspec(pos)
 end,
 
 on_receive_fields = function(pos, formname, fields, player)
  local meta = minetest.get_meta(pos)
  if fields.percent then
   meta:set_string("percent", ""..(tonumber(fields.percent) or 0))
  end
  if fields.dst then
   meta:set_string("dst", fields.dst)
  end
  
  if fields.mode then
   local mode = meta:get_string("mode")
   if mode == "<" then
    meta:set_string("mode", ">");
   else
    meta:set_string("mode", "<");
   end
  end
  -- rebuild as node may have changed
  build_formspec(pos)
  local txt = meta:get_string("dst").."  "..meta:get_string("percent")
  minetest.chat_send_player("singleplayer", txt)
 end,
 on_timer = on_timer,
 after_dig_node = function(pos, oldnode, oldmetadata, digger) 
  mesecon.receptor_off(pos) 
 end,
 mesecons = mesecon_rules,
})

minetest.register_craft({
 output = "hopper:compair",
 recipe = {
  {"default:steel_ingot", "group:mesecon_conductor_craftable", "default:steel_ingot"},
  {"group:stone", "group:stone", "group:stone"},
 },
})